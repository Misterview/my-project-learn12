// const connectDB = require("../db")

// module.exports = async(req,res,next) =>{
//    if(req.session.adminID){
//       return res.render("admin.hbs")
//    }
// }