# Welcome to BCMMDev project 2023

![Frontend + Backend](https://github.com/ChatchawanDew404/BCMMdev_project_2023/assets/89406698/800ff8fd-694b-4d37-ae9d-fc7d81316565)

💖 How to use code files from GitHub

- use git clone

- open project
- use "npm install" in terminal
- use "npm run dev" to run project

------
💖 ALL SYSTEM

[🟢 CLIENT]

- show all blog slide

- search blog name

- select category blog

- read blog

- show all post community slide

- select category post

- create post

- comment post

- contact us

- 404 page

[🟢 ADMIN DASHBOARD]

- login admin dashboard

- Show data analysis results

- display all blog information

- search blog name

- create blog

- edit blog

- delete blog

- display all contact information

- explore Contact Content

- simulate contact back

- delete contact

- display all admin information

- search admin name

- create admin

- edit admin

- delete admin

- logout admin


------------
🟢 DATABASE : MYSQL Workbench
